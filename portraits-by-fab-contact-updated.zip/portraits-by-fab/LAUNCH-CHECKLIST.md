# Portraits by Fab — launch checklist

## Before publishing
- [ ] Add your WhatsApp number to `lib/site.ts` → `contact.whatsapp` in international format, digits only (UK example: `447XXXXXXXXX`).
- [ ] Add your hero image as `public/images/hero.jpg` (wide landscape, ideally 2000px+).
- [ ] Add your portrait as `public/images/fab.jpg` (portrait crop).
- [ ] Add portfolio images in `public/images/` and update `photos` in `lib/site.ts` with each file path, accurate alt text, and category.
- [ ] Add only genuine testimonials and service details that reflect your business.

## Publish
1. Create a GitHub repository and upload this project.
2. Sign in to Vercel and import the GitHub repository.
3. Deploy using the detected Next.js defaults.
4. In Vercel project settings → Domains, add `portraitsbyfab.com` and follow the DNS records shown there at your domain registrar.
5. Wait for domain verification and HTTPS.
6. Test the website on mobile and desktop, including the WhatsApp enquiry flow.

## Important
The booking form validates details and prepares a WhatsApp enquiry, but it does not store submissions or email them. Add your WhatsApp number before launch and test the pre-filled message.
